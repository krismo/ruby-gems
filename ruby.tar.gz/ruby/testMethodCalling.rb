def update_message(message)
    puts message
end

update_message("Hi")